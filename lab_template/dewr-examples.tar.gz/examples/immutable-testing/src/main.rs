/*
Uses lib.rs to add all the elements in the vector
*/
use immutable_testing::add;

fn main() {
    //print the result
    println!("The sum of the elements in the vector is: {}", add());
}
